let uploads = JSON.parse(localStorage.getItem('uploads')) || [];

export const addUpload = (gifId) => {
    if (uploads.find(id => id === gifId)) {
      // Movie has already been added to favorites
      return;
    }
  
    uploads.push(gifId);
    localStorage.setItem('favorites', JSON.stringify(uploads));
};
  
export const getUploads = () => [...uploads];