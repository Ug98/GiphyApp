export const toAboutView = () => `
<div id="about">
  <div class="content">
    <h1>About the app</h1>
    <h2>Authors: Telerik Academy</h2>
    <h2>Date: 2021</h2>
  </div>
</div>
`;
