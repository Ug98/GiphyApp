import { getUploads } from "../data/uploads.js";

export const toUploadView = (gifs) => `
<div id="upload">
    <input type="file" id="upload-gif" accept="image/*">
    <button id="upload-button">Upload GIF</button>
</div>
<div id="uploaded">
    ${gifs.map(gif => `<div class="grid-item"><img src="${gif.images}"></div>`).join(`\n`)}
</div>
`;