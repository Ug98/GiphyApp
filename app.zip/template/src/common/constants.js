export const HOME = 'home';

export const TRENDING = 'trending';

export const UPLOAD = 'upload';

export const FAVORITES = 'favorites';

export const ABOUT = 'about';

export const CONTAINER_SELECTOR = '#container';

export const FULL_HEART = '❤';

export const EMPTY_HEART = '♡';

export const API_KEY = 'pmxjQfXSH3Nsnbg1hsjtBpKqeK1KciD3';

export const API_USER = 'GGa62';