import { uploadGif } from '../requests/request-service.js';
import { API_KEY, API_USER } from '../common/constants.js';
import { q } from './helpers.js';

export const uploadFile = () => {
    try {
      const fileInput = q('#upload-gif');
      const formData = new FormData();
      formData.append('file', fileInput.files[0]);
      formData.append('api_key', API_KEY);
      formData.append('username', API_USER);
    } catch (error) {
      console.error('Error creating FormData from new GIF:', error.message);
      alert('Error creating FormData from new GIF:', error.message, `\n !!! Data Status: ${data.meta.status}`);
    };
    
    try {
      uploadGif(formData)
      .then(data => {
        if (data.status.ok) {
          alert('GIF uploaded successfully!');
        }
      })
    } catch (error) {
      console.error('Error uploading GIF:', error.message);
      alert('Error uploading GIF:', error.message, `\n !!! Data Status: ${data.meta.status}`);
    };
};